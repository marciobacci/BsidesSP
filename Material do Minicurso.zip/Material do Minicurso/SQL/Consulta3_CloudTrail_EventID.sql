SELECT
  "$path",
  eventtime,
  eventname,
  useridentity.username
FROM cloudtrail_logs
WHERE eventid = 'INFORMAR_ID_EVENTO_CLOUDTRAIL'
  AND region = 'us-east-1'
  AND year = '2026'
  AND month = '05'
  AND day = '01';
