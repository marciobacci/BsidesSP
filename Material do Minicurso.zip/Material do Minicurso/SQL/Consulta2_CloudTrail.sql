SELECT
  "$path" AS log_file,
  eventtime,
  useridentity.username,
  eventname,
  sourceipaddress
FROM cloudtrail_logs
WHERE useridentity.username = 'zezinho'
AND json_extract_scalar(requestparameters, '$.bucketName') = 'financeiro-90kd5cl0'
ORDER BY eventtime;