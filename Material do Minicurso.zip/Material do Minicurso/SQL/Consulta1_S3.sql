SELECT
  "$path" AS log_file,
  requester,
  remote_ip,
  user_agent,
  key,
  request_datetime,
  http_status,
  bytes_sent
FROM s3_logs_forense.s3_access_logs
WHERE operation = 'REST.GET.OBJECT'
ORDER BY request_datetime;