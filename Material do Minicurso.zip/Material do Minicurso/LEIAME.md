1\. Toda a infraestrutura necessária para a criação do laboratório é criada através do template Forense\_AWS\_BSidesSP\_2026\_v2.yaml. Execute-o no AWS CloudFormation.



**OBS:** Devido mudanças recentes na política AWS, para novas contas AWS será necessário fazer o **upgrade de conta** por conta da ativação do AWS **Macie** (ferramenta de DLP).

\----------------------------------------------------------------------------------------------------



2\. Ao final do laboratório recomenda-se a exclusão de toda a infraestrutura para evitar possíveis cobranças. Utilize o script ExcluirLab.sh



**OBS:** Após a exclusão com sucesso verifique se tudo realmente foi excluído. Normalmente o bucket forense precisa ser esvaziado e depois deletado. Para todos os demais recursos verificou-se que foram excluídos com sucesso, entretanto **VERIFIQUE!**

\----------------------------------------------------------------------------------------------------------



3\. Todos os scripts devem ser ajustados para refletirem exatamente o nome dos buckets que a cada criação do laboratório recebem um sufixo aleatório diferente.

\----------------------------------------------------------------------------------------------------------



4\. Os demais arquivos de políticas e scripts SQL estão sendo fornecidos apenas para o entendimento desses, não havendo necessidade de utilização direta, pois o template Forense\_AWS\_BSidesSP\_2026\_v2.yaml

&#x20;cria toda a infraestrutura necessária.

\----------------------------------------------------------------------------------------------------------

