#!/bin/bash
set -euo pipefail

FORENSIC_BUCKET="forense-44d1zr0b"
QUERY_PREFIX="query-athena"
DEST_BASE_PREFIX="cadeia-custodia"

TIMESTAMP_UTC="$(date -u +%Y%m%dT%H%M%SZ)"
CASE_ID="coleta_aws_${TIMESTAMP_UTC}"

DEST_PREFIX="${DEST_BASE_PREFIX}/${CASE_ID}"
LOCAL_TEMP="/tmp/${CASE_ID}"

MANIFESTO="${LOCAL_TEMP}/manifesto.txt"
MANIFESTO_HASH="${LOCAL_TEMP}/manifesto.txt.sha256"
HASHES_FILE="${LOCAL_TEMP}/hashes_evidencias_sha256.txt"
LOG_EXEC="${LOCAL_TEMP}/execucao.log"
CSVS_FILE="${LOCAL_TEMP}/csvs.txt"
LOGS_FILE="${LOCAL_TEMP}/logs_processamento.tmp"

TOTAL_BYTES=0
TOTAL_ARQUIVOS=0

export AWS_PAGER=""

mkdir -p "$LOCAL_TEMP"
exec > >(tee -a "$LOG_EXEC") 2>&1

echo "===================================================="
echo "INICIO DA COLETA PERICIAL"
echo "Caso..............: $CASE_ID"
echo "Data/Hora UTC.....: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo "Fonte Athena......: s3://${FORENSIC_BUCKET}/${QUERY_PREFIX}/"
echo "Destino S3........: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/"
echo "===================================================="
echo ""

echo "[*] Validando identidade AWS"
aws sts get-caller-identity --output json
echo ""

{
  echo "MANIFESTO DE CADEIA DE CUSTODIA"
  echo "Caso: $CASE_ID"
  echo "Data/Hora UTC de inicio: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
  echo "Ambiente: AWS CloudShell"
  echo "Fonte das consultas Athena: s3://${FORENSIC_BUCKET}/${QUERY_PREFIX}/"
  echo "Destino das evidencias: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/"
  echo "Metodo: coleta seletiva dos logs referenciados nos resultados Athena"
  echo ""
  echo "Observacao sobre hashes:"
  echo "SHA256 do arquivo preservado (.gz): hash do objeto coletado e armazenado."
  echo "SHA256 do conteudo descompactado: hash utilizado para confrontacao com CloudTrail Digest."
  echo "----------------------------------------------------"
} > "$MANIFESTO"

> "$HASHES_FILE"
> "$LOGS_FILE"

aws s3 ls "s3://${FORENSIC_BUCKET}/${QUERY_PREFIX}/" \
  | awk '/\.csv$/ && $4 !~ /\.metadata$/ {print $4}' \
  > "$CSVS_FILE"

if [ ! -s "$CSVS_FILE" ]; then
  echo "[ERRO] Nenhum CSV encontrado em s3://${FORENSIC_BUCKET}/${QUERY_PREFIX}/"
  exit 1
fi

while read -r CSV_FILE; do
  echo "[*] Processando CSV: $CSV_FILE"

  LOCAL_CSV="${LOCAL_TEMP}/${CSV_FILE}"

  aws s3 cp \
    "s3://${FORENSIC_BUCKET}/${QUERY_PREFIX}/${CSV_FILE}" \
    "$LOCAL_CSV" \
    --quiet

  HEADER="$(head -1 "$LOCAL_CSV" | tr ',' '\n' | sed 's/^"//; s/"$//; s/\r$//')"

  COL_INDEX=""
  COL_NAME=""

  i=1
  while read -r col; do
    if [[ "$col" == "log_file" || "$col" == '$path' ]]; then
      COL_INDEX=$i
      COL_NAME=$col
      break
    fi
    ((i++))
  done <<< "$HEADER"

  if [ -z "$COL_INDEX" ]; then
    echo "[!] CSV ignorado: não contém coluna log_file ou \$path"
    continue
  fi

  awk -F',' -v col="$COL_INDEX" '
    NR > 1 {
      gsub(/^"|"$/, "", $col)
      gsub(/\r$/, "", $col)

      if ($col ~ /^s3:\/\//)
        print $col
    }
  ' "$LOCAL_CSV" >> "$LOGS_FILE"

done < "$CSVS_FILE"

sort -u "$LOGS_FILE" -o "$LOGS_FILE"

if [ ! -s "$LOGS_FILE" ]; then
  echo "[ERRO] Nenhum caminho S3 de log encontrado nos CSVs."
  exit 1
fi

{
  echo ""
  echo "[FONTES IDENTIFICADAS]"
  echo "Total de arquivos-fonte unicos identificados: $(wc -l < "$LOGS_FILE")"
  echo "----------------------------------------------------"
} >> "$MANIFESTO"

while IFS= read -r S3_FULL_PATH; do
  echo "[>] Preservando: $S3_FULL_PATH"

  S3_BUCKET="$(echo "$S3_FULL_PATH" | cut -d'/' -f3)"
  S3_KEY="$(echo "$S3_FULL_PATH" | cut -d'/' -f4-)"

  SAFE_NAME="$(echo "${S3_BUCKET}_${S3_KEY}" | sed 's#[/ ]#_#g')"
  LOCAL_FILE="${LOCAL_TEMP}/${SAFE_NAME}"

  HEAD_JSON="$(aws s3api head-object --bucket "$S3_BUCKET" --key "$S3_KEY" 2>/dev/null || true)"

  if [ -z "$HEAD_JSON" ]; then
    echo "[!] Falha ao obter metadados: $S3_FULL_PATH"
    echo "Falha ao obter metadados: $S3_FULL_PATH" >> "$MANIFESTO"
    continue
  fi

  LAST_MODIFIED="$(echo "$HEAD_JSON" | jq -r '.LastModified // "Nao identificado"')"
  CONTENT_LENGTH="$(echo "$HEAD_JSON" | jq -r '.ContentLength // 0')"
  ETAG="$(echo "$HEAD_JSON" | jq -r '.ETag // "Nao identificado"' | tr -d '"')"
  VERSION_ID="$(echo "$HEAD_JSON" | jq -r '.VersionId // empty')"

  aws s3 cp "$S3_FULL_PATH" "$LOCAL_FILE" --quiet

  HASH_SHA256_GZ="$(sha256sum "$LOCAL_FILE" | awk '{print $1}')"

  if [[ "$LOCAL_FILE" == *.gz ]]; then
    HASH_SHA256_CONTENT="$(gunzip -c "$LOCAL_FILE" | sha256sum | awk '{print $1}')"
  else
    HASH_SHA256_CONTENT="$HASH_SHA256_GZ"
  fi

  DEST_KEY="${DEST_PREFIX}/evidencias/${S3_BUCKET}/${S3_KEY}"

  aws s3 cp "$LOCAL_FILE" "s3://${FORENSIC_BUCKET}/${DEST_KEY}" \
    --metadata \
      "sha256-gz=${HASH_SHA256_GZ},sha256-content=${HASH_SHA256_CONTENT},aws-integrity=cadeia-custodia,source-bucket=${S3_BUCKET},source-etag=${ETAG}" \
    --quiet

  {
    echo "Evidencia: s3://${FORENSIC_BUCKET}/${DEST_KEY}"
    echo "Origem: $S3_FULL_PATH"
    echo "SHA256 arquivo preservado (.gz): $HASH_SHA256_GZ"
    echo "SHA256 conteudo descompactado: $HASH_SHA256_CONTENT"
    echo "----------------------------------------------------"
  } >> "$HASHES_FILE"

  TOTAL_BYTES=$((TOTAL_BYTES + CONTENT_LENGTH))
  TOTAL_ARQUIVOS=$((TOTAL_ARQUIVOS + 1))

  {
    echo "Evidencia preservada"
    echo "Origem: $S3_FULL_PATH"
    echo "Destino: s3://${FORENSIC_BUCKET}/${DEST_KEY}"
    echo "SHA256 arquivo preservado (.gz): $HASH_SHA256_GZ"
    echo "SHA256 conteudo descompactado: $HASH_SHA256_CONTENT"
    echo "LastModified origem: $LAST_MODIFIED"
    echo "ContentLength bytes: $CONTENT_LENGTH"
    echo "ETag origem: $ETAG"
    echo "VersionId origem: ${VERSION_ID:-Nao versionado}"
    echo "----------------------------------------------------"
  } >> "$MANIFESTO"

  rm -f "$LOCAL_FILE"

done < "$LOGS_FILE"

TOTAL_KB=$(awk "BEGIN {printf \"%.2f\", $TOTAL_BYTES/1024}")
TOTAL_MB=$(awk "BEGIN {printf \"%.2f\", $TOTAL_BYTES/1024/1024}")
TOTAL_GB=$(awk "BEGIN {printf \"%.4f\", $TOTAL_BYTES/1024/1024/1024}")

{
  echo ""
  echo "[RESUMO DA COLETA]"
  echo "Data/Hora UTC de termino: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
  echo "Total de evidencias preservadas: $TOTAL_ARQUIVOS"
  echo "Tamanho total das evidencias:"
  echo "  Bytes: $TOTAL_BYTES"
  echo "  KB: $TOTAL_KB"
  echo "  MB: $TOTAL_MB"
  echo "  GB: $TOTAL_GB"
  echo "Localizacao final: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/"
  echo "----------------------------------------------------"
} >> "$MANIFESTO"

sha256sum "$MANIFESTO" > "$MANIFESTO_HASH"

aws s3 cp "$MANIFESTO" \
  "s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/manifesto.txt" \
  --quiet

aws s3 cp "$MANIFESTO_HASH" \
  "s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/manifesto.txt.sha256" \
  --quiet

aws s3 cp "$HASHES_FILE" \
  "s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/hashes_evidencias_sha256.txt" \
  --quiet

aws s3 cp "$LOG_EXEC" \
  "s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/execucao.log" \
  --quiet

echo ""
echo "===================================================="
echo "COLETA CONCLUIDA"
echo "Caso..............: $CASE_ID"
echo "Evidencias........: $TOTAL_ARQUIVOS"
echo "Tamanho total.....: $TOTAL_BYTES bytes"
echo "Tamanho total MB..: $TOTAL_MB MB"
echo "Destino S3........: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/"
echo "Manifesto.........: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/manifesto.txt"
echo "Hash manifesto....: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/manifesto.txt.sha256"
echo "Hashes evidencias.: s3://${FORENSIC_BUCKET}/${DEST_PREFIX}/manifesto/hashes_evidencias_sha256.txt"
echo "===================================================="

