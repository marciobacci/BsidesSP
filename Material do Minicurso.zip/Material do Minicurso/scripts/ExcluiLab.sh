#!/bin/bash

set -euo pipefail

########################################
# CONFIGURAÇÕES
########################################

STACK_NAME="BSidesSP2026"
REGION="us-east-1"

WORKGROUP="forense-workgroup-sby1xtpa"
TRAIL_NAME="trail-sby1xtpa"

BUCKET_FORENSE="forense-sby1xtpa"
BUCKET_FINANCEIRO="financeiro-sby1xtpa"
BUCKET_S3_LOGS="s3-logs-sby1xtpa"
BUCKET_TRAIL_LOGS="trail-logs-sby1xtpa"

BUCKETS=(
  "$BUCKET_FORENSE"
  "$BUCKET_FINANCEIRO"
  "$BUCKET_S3_LOGS"
  "$BUCKET_TRAIL_LOGS"
)

########################################
# FUNÇÕES
########################################

function bucket_exists() {

  local bucket=$1

  aws s3api head-bucket \
    --bucket "$bucket" 2>/dev/null
}

function empty_bucket_completely() {

  local bucket=$1

  echo ""
  echo "=========================================="
  echo "LIMPANDO BUCKET: $bucket"
  echo "=========================================="

  if ! bucket_exists "$bucket"; then
    echo "Bucket não existe: $bucket"
    return
  fi

  ########################################
  # REMOVE OBJETOS NORMAIS
  ########################################

  echo ""
  echo "[1/4] Removendo objetos normais..."

  aws s3 rm "s3://$bucket" \
    --recursive || true

  ########################################
  # REMOVE VERSÕES E DELETE MARKERS
  ########################################

  echo ""
  echo "[2/4] Removendo versões e delete markers..."

  ATTEMPTS=0
  MAX_ATTEMPTS=30

  while true; do

    RESPONSE=$(aws s3api list-object-versions \
      --bucket "$bucket" \
      --output json)

    COUNT=$(echo "$RESPONSE" | jq '
      ((.Versions // []) + (.DeleteMarkers // [])) | length')

    echo "Itens encontrados neste lote: $COUNT"

    if [ "$COUNT" -eq 0 ]; then
      echo "Nenhuma versão restante."
      break
    fi

    echo "$RESPONSE" | jq -r '
      ((.Versions // []) + (.DeleteMarkers // []))[]
      | "Removendo: \(.Key) | \(.VersionId)"'

    echo "$RESPONSE" | jq -c '
    {
      Objects:
      (
        ((.Versions // []) | map({Key:.Key,VersionId:.VersionId})) +
        ((.DeleteMarkers // []) | map({Key:.Key,VersionId:.VersionId}))
      ),
      Quiet: true
    }' > delete.json

    aws s3api delete-objects \
      --bucket "$bucket" \
      --delete file://delete.json >/dev/null || true

    rm -f delete.json

    sleep 5

    ATTEMPTS=$((ATTEMPTS + 1))

    if [ "$ATTEMPTS" -ge "$MAX_ATTEMPTS" ]; then

      echo ""
      echo "ATENÇÃO:"
      echo "Loop detectado ao limpar bucket $bucket"
      echo "Possível propagação atrasada do CloudTrail."
      echo "Continuando execução do cleanup..."

      break
    fi
  done

  ########################################
  # ABORTA MULTIPART UPLOADS
  ########################################

  echo ""
  echo "[3/4] Abortando multipart uploads..."

  MULTIPARTS=$(aws s3api list-multipart-uploads \
    --bucket "$bucket" \
    --query 'Uploads[].{Key:Key,UploadId:UploadId}' \
    --output json 2>/dev/null || echo '[]')

  COUNT_UPLOADS=$(echo "$MULTIPARTS" | jq 'length')

  echo "Multipart uploads encontrados: $COUNT_UPLOADS"

  if [ "$COUNT_UPLOADS" -gt 0 ]; then

    echo "$MULTIPARTS" | jq -c '.[]' | while read upload; do

      KEY=$(echo "$upload" | jq -r '.Key')
      UPLOAD_ID=$(echo "$upload" | jq -r '.UploadId')

      echo "Abortando upload: $KEY"

      aws s3api abort-multipart-upload \
        --bucket "$bucket" \
        --key "$KEY" \
        --upload-id "$UPLOAD_ID" || true
    done
  fi

  ########################################
  # VALIDAÇÃO FINAL
  ########################################

  echo ""
  echo "[4/4] Validação final..."

  FINAL_CHECK=$(aws s3api list-object-versions \
    --bucket "$bucket" \
    --output json)

  FINAL_COUNT=$(echo "$FINAL_CHECK" | jq '
    ((.Versions // []) + (.DeleteMarkers // [])) | length')

  if [ "$FINAL_COUNT" -eq 0 ]; then

    echo "Bucket completamente vazio."

  else

    echo "ATENÇÃO:"
    echo "Ainda existem objetos restantes."
    echo "Quantidade restante: $FINAL_COUNT"

    echo ""
    echo "Objetos restantes:"

    echo "$FINAL_CHECK" | jq -r '
      ((.Versions // []) + (.DeleteMarkers // []))[]
      | "- \(.Key) | \(.VersionId)"'
  fi
}

########################################
# INÍCIO
########################################

echo ""
echo "=================================================="
echo "INICIANDO CLEANUP COMPLETO DO LABORATÓRIO"
echo "=================================================="

########################################
# CLOUDTRAIL
########################################

echo ""
echo "[ETAPA 1] Parando CloudTrail..."

aws cloudtrail stop-logging \
  --name "$TRAIL_NAME" \
  --region "$REGION" || true

echo "Aguardando propagação do CloudTrail..."
sleep 20

########################################
# DESABILITA BUCKET LOGGING
########################################

echo ""
echo "[ETAPA 2] Desabilitando bucket logging..."

for BUCKET in "${BUCKETS[@]}"; do

  if bucket_exists "$BUCKET"; then

    echo "Desativando logging: $BUCKET"

    aws s3api put-bucket-logging \
      --bucket "$BUCKET" \
      --bucket-logging-status '{}' || true
  fi

done

########################################
# LIMPA BUCKETS
########################################

echo ""
echo "[ETAPA 3] Limpando buckets..."

for BUCKET in "${BUCKETS[@]}"; do
  empty_bucket_completely "$BUCKET"
done

########################################
# REMOVE ATHENA WORKGROUP
########################################

echo ""
echo "[ETAPA 4] Removendo Athena WorkGroup..."

aws athena delete-work-group \
  --work-group "$WORKGROUP" \
  --recursive-delete-option \
  --region "$REGION" || true

########################################
# REMOVE BUCKETS
########################################

echo ""
echo "[ETAPA 5] Removendo buckets..."

for BUCKET in "${BUCKETS[@]}"; do

  if bucket_exists "$BUCKET"; then

    echo "Removendo bucket: $BUCKET"

    aws s3 rb \
      "s3://$BUCKET" \
      --force || true
  fi

done

########################################
# DELETE STACK
########################################

echo ""
echo "[ETAPA 6] Deletando CloudFormation Stack..."

aws cloudformation delete-stack \
  --stack-name "$STACK_NAME" \
  --region "$REGION"

########################################
# AGUARDA FINALIZAÇÃO
########################################

echo ""
echo "[ETAPA 7] Aguardando exclusão completa da stack..."

aws cloudformation wait stack-delete-complete \
  --stack-name "$STACK_NAME" \
  --region "$REGION"

########################################
# FINAL
########################################

echo ""
echo "=================================================="
echo "CLEANUP FINALIZADO COM SUCESSO"
echo "=================================================="