#!/usr/bin/env bash

# ===== VARIAVEIS =====
#!/bin/bash
USER_NAME="zezinho"
GROUP_NAME="financeiro-sby1xtpa"
POLICY_NAME="s3-excessivo-financeiro"
OUTPUT="coleta_iam_${USER_NAME}.txt"

# =====================

{
  echo "========================================"
  echo "COLETA IAM - USUARIO ${USER_NAME}"
  echo "Data/Hora (UTC): $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "========================================"
  echo ""

  echo "[1] Comando executado:"
  echo "aws iam get-user --user-name ${USER_NAME}"
  echo "Saída:"
  aws iam get-user --user-name "${USER_NAME}"
  echo ""

  echo "[2] Comando executado:"
  echo "aws iam list-attached-user-policies --user-name ${USER_NAME}"
  echo "Saída:"
  aws iam list-attached-user-policies --user-name "${USER_NAME}"
  echo ""

  echo "[3] Comando executado:"
  echo "aws iam list-groups-for-user --user-name ${USER_NAME}"
  echo "Saída:"
  aws iam list-groups-for-user --user-name "${USER_NAME}"
  echo ""

  echo "[4] Comando executado:"
  echo "aws iam list-group-policies --group-name ${GROUP_NAME}"
  echo "Saída:"
  aws iam list-group-policies --group-name "${GROUP_NAME}"
  echo ""

  echo "[5] Comando executado:"
  echo "aws iam get-group-policy --group-name ${GROUP_NAME} --policy-name ${POLICY_NAME}"
  echo "Saída:"
  aws iam get-group-policy --group-name "${GROUP_NAME}" --policy-name "${POLICY_NAME}"
  echo ""

} > "$OUTPUT" 2>&1

echo "Arquivo gerado: $OUTPUT"

echo "[*] Gerando hash SHA-256 do arquivo de coleta"
sha256sum "$OUTPUT" > "${OUTPUT}.sha256"

echo ""
echo "========================================"
echo "COLETA FINALIZADA"
echo "Arquivo........: $OUTPUT"
echo "Hash...........: ${OUTPUT}.sha256"
echo "========================================"